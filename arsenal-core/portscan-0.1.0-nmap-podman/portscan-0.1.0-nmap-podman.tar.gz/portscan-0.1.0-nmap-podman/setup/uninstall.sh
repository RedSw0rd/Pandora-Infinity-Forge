#!/bin/bash
# Version : 7.95-r10
tag="[PANDORA::ARSENAL]"
journal="pandora-app"
ImageDigest="sha256:164444eaf1b129b9f538b9074200bab016566f309ff030ee1d6f953cda58244e"
ImageName="docker.io/instrumentisto/nmap@${ImageDigest}"

# Remove the image
podman rmi $ImageName
if [ $? -ne 0 ];
then
        logger -t "$journal" "$tag Uninstallation failed - 'podman rmi command' failed"
        exit 1
fi

sleep 1

# Confirm image removal
podman image exists $ImageName
if [ $? -ne 0 ];
then
        logger -t "$journal" "$tag Uninstallation success"
        exit 0
else
        logger -t "$journal" "$tag Uninstallation failed - 'podman image exists' command failed"
        exit 1
fi
