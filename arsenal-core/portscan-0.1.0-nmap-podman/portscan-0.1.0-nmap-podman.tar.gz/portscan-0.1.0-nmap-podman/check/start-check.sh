#!/bin/bash

podman run --rm -it --network host --cap-add=NET_RAW instrumentisto/nmap -V | grep 'Nmap version 7.95 ( https://nmap.org )' > /dev/null
if [ $? -ne 0 ];
then
        exit 0
else
        exit 1
fi
