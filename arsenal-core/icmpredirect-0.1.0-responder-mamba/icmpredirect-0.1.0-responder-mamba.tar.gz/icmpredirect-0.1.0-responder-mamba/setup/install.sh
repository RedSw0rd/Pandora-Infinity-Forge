#!/bin/bash

envname="responder"
tag="[PANDORA::ARSENAL]"
journal="pandora-app"

# GIT CONFIG
gitrepo="https://github.com/lgandx/Responder.git"
gitfolder="/opt/pandora/github/responder"
gitbranch="v3.1.6.0"

# MICROMAMBA
currentdir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
mamba_env_file="$currentdir/config.yaml"
mamba_bin_path="/opt/micromamba/bin/micromamba"

logger -t "$journal" "$tag Installation success"
exit 0
