#!/bin/bash

/opt/micromamba/envs/lsassy/bin/python -W ignore -u /opt/micromamba/envs/lsassy/bin/lsassy --version | grep 'lsassy (version' > /dev/null
if [ $? -eq 0 ];
then
        exit 0
else
        exit 1
fi
