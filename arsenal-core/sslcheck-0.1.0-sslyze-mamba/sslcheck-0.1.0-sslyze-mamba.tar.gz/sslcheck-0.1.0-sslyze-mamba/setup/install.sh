#!/bin/bash

envname="sslyze"
tag="[PANDORA::ARSENAL]"
journal="pandora-app"
conda_env_file="setup/config.yaml"
conda_bin_path="/opt/micromamba/bin/micromamba"

# Verify the presence of the environment configuration file
if [ ! -f "$conda_env_file" ];
then
	logger -t "$journal" "$tag Installation failed - Conda environment file '$conda_env_file' not found"
	exit 1
fi

# Install the Conda environment from the file
"$conda_bin_path" env create -f "$conda_env_file"
if [ $? -ne 0 ];
then
	logger -t "$journal" "$tag Installation failed - 'conda env create' command failed"
	exit 1
fi

sleep 1

# Confirm Conda environment installation
if "$conda_bin_path" env list | grep -q "$envname";
then
	logger -t "$journal" "$tag Installation success"
	exit 0
else
	logger -t "$journal" "$tag Installation failed - Conda environment '$envname' not found after creation"
	exit 1
fi
