#!/bin/bash

/opt/micromamba/envs/theharvester/bin/python -W ignore -u /opt/pandora/github/theharvester/theHarvester.py --help | grep 'cmartorella@edge-security.com' > /dev/null
if [ $? -eq 0 ];
then
        exit 0
else
        exit 1
fi
