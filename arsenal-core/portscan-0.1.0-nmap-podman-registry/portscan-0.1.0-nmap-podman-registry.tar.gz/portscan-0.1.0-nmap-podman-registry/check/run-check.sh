#!/bin/bash

ImageDigest="sha256:164444eaf1b129b9f538b9074200bab016566f309ff030ee1d6f953cda58244e"
ImageName="docker.io/instrumentisto/nmap@${ImageDigest}"

podman run --rm -it --network host --cap-add=NET_RAW ${ImageName} -sS --top-port 10 127.0.0.1 > /dev/null
if [ $? -eq 0 ];
then
        exit 0
else
        exit 1
fi
