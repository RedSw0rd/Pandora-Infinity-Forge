#!/bin/bash

/opt/micromamba/envs/arjun/bin/python -W ignore -u /opt/micromamba/envs/arjun/bin/arjun --help | grep 'arjun' > /dev/null
if [ $? -eq 0 ];
then
        exit 0
else
        exit 1
fi
