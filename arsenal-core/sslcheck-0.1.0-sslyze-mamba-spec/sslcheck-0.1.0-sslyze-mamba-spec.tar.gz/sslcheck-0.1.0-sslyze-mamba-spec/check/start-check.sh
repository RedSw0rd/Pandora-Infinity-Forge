#!/bin/bash

/opt/micromamba/envs/sslyze/bin/python -W ignore -u /opt/micromamba/envs/sslyze/bin/sslyze -h | grep 'SSLyze version 6.1.0' > /dev/null
if [ $? -eq 0 ];
then
        exit 0
else
        exit 1
fi
