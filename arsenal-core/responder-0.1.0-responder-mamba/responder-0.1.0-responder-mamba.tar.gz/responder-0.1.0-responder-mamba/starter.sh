#!/bin/bash

cd "$(dirname "${BASH_SOURCE[0]}")"

if [[ -e "setup/install.sh" ]]
then
        source "setup/install.sh"
fi
