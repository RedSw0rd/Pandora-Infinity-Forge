#!/bin/bash

journal="pandora-app"
tag="[PANDORA::ARSENAL]"

binName="gospider"
binVersion="v1.1.6"
binfolder="/opt/pandora/gobinary/$binName"
tempArchive="/tmp/download.zip"

arch=$(uname -m)
archUrl=""

if [ "$arch" = "x86_64" ];
then
        archUrl="x86_64"

elif [ "$arch" = "aarch64" ];
then
        archUrl="arm64"
else
        logger -t "$journal" "$tag Installation failed - Unsupported architecture: $arch"
        exit 1
fi

binUrl="https://github.com/jaeles-project/gospider/releases/download/${binVersion}/gospider_${binVersion}_linux_${archUrl}.zip"

#
if [ ! -d "$binfolder" ];
then
        mkdir -p "$binfolder"
fi

if [ ! -d "$binfolder" ];
then
        logger -t "$journal" "$tag Installation failed - Could not create binary folder '$binfolder'"
        exit 1
fi

# Download the archive silently
wget -q "$binUrl" -O "$tempArchive"
if [ $? -ne 0 ];
then
        logger -t "$journal" "$tag Installation failed - 'wget' command failed to download '$binUrl'"
        exit 1
fi

mkdir "/tmp/_$binName"
unzip -o -q "$tempArchive" -d "/tmp/_$binName"
if [ $? -ne 0 ];
then
        logger -t "$journal" "$tag Installation failed - 'unzip' command failed for '$tempArchive'"

        # Clean up downloaded file even if unzip fails
        rm -f "$tempArchive"
        exit 1
fi

mv /tmp/_${binName}/* /tmp/${binName}
rm -rf "/tmp/_$binName"
mv "/tmp/$binName/$binName" "$binfolder/$binName"
if [ $? -ne 0 ]; then
        logger -t "$journal" "$tag Installation failed - 'mv' command failed to copy $binName binary to '$binfolder'"

        # Clean up
        rm -rf "$tempArchive" "/tmp/$binName"
        exit 1
fi

chmod +x "$binfolder/$binName"
if [ $? -ne 0 ];
then
        logger -t "$journal" "$tag WARNING - 'chmod' command failed for '$binfolder/$binName' - Run the command as root : chmod +x '$binfolder/$binName'"
fi

# Clean
rm -rf "$tempArchive" "/tmp/$binName"

# Confirm installation success
logger -t "$journal" "$tag Installation success - $binName binary installed to '$binfolder'"
exit 0

