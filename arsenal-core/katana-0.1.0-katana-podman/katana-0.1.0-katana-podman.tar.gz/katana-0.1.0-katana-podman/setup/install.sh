#!/bin/bash
tag="[PANDORA::ARSENAL]"
journal="pandora-app"

#
gitrepo="https://github.com/projectdiscovery/katana.git"
gitfolder="/opt/pandora/github/katana_"
gitbranch="v1.4.0"
ImageName="Pandora/katana:${gitbranch}"

# Cloning
git clone --branch "$gitbranch" --depth 1 --single-branch "$gitrepo" "$gitfolder" >/dev/null 2>&1
if [ $? -ne 0 ];
then
        logger -t "$journal" "$tag Installation failed - 'git clone' command failed"
        exit 1
fi

cd "$gitfolder"
podman build -t "$ImageName" .
if [ $? -ne 0 ];
then
        logger -t "$journal" "$tag Installation failed - 'podman build command' failed"
        exit 1
fi

sleep 1

# Confirm image installation
podman image exists $ImageName
if [ $? -eq 0 ];
then
        logger -t "$journal" "$tag Installation success"
        exit 0
else
        logger -t "$journal" "$tag Installation failed - 'podman image don't exists' command failed"
        exit 1
fi

# Remove git folder
if [ -d "$gitfolder" ];
then
        rm -rf "$gitfolder"
else
        logger -t "$journal" "$tag Git folder '$gitfolder' not found"
fi
