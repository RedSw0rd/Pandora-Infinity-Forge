#!/bin/bash
tag="[PANDORA::ARSENAL]"
journal="pandora-app"
ImageName="Pandora/katana:v1.4.0"

# Remove the image
podman rmi -f $ImageName
if [ $? -ne 0 ];
then
        logger -t "$journal" "$tag Uninstallation failed - 'podman rmi command' failed"
        exit 1
fi

sleep 1

# Confirm image removal
podman image exists $ImageName
if [ $? -ne 0 ];
then
        logger -t "$journal" "$tag Uninstallation success"
        exit 0
else
        logger -t "$journal" "$tag Uninstallation failed - 'podman image exists' command failed"
        exit 1
fi
