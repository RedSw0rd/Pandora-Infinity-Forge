#!/bin/bash

podman run --rm Pandora/katana:v1.4.0 -version 2>/dev/stdout | grep 'projectdiscovery.io' > /dev/null
if [ $? -eq 0 ];
then
        exit 0
else
        exit 1
fi
