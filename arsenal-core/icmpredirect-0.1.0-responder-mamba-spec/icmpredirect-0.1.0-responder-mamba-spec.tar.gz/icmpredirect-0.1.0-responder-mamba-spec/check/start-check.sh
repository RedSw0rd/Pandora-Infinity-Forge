#!/bin/bash

/opt/micromamba/envs/responder/bin/python -W ignore -u /opt/pandora/github/responder/tools/Icmp-Redirect.py | grep 'redirect the victim traffic' > /dev/null
if [ $? -eq 0 ];
then
        exit 0
else
        exit 1
fi
