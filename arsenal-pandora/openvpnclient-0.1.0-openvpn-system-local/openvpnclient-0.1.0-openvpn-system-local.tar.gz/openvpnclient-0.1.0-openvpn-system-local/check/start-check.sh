#!/bin/bash

/usr/sbin/openvpn --version | grep 'Originally developed by James Yonan' > /dev/null
if [ $? -eq 0 ];
then
        exit 0
else
        exit 1
fi
