#!/bin/bash

envname="/opt/micromamba/envs/automate"
tag="[PANDORA::ARSENAL]"
journal="pandora-app"
micromamba_bin_path="/opt/micromamba/bin/micromamba"

logger -t "$journal" "$tag Uninstallation blocked - This micromamba environment 'envname' is used by Pandora for internal purpose"
exit 1
