#!/bin/bash

/opt/micromamba/envs/automate/bin/python -W ignore -u /var/lib/pandora/sys/scripts/pandora/offensive/passcampaign.py | grep '<XID> <UID> <THREADS> <SOCKS>' > /dev/null
if [ $? -eq 0 ];
then
        exit 0
else
        exit 1
fi
