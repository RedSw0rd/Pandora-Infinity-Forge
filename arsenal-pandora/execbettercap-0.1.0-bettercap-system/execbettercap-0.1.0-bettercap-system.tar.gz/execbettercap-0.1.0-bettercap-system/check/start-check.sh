#!/bin/bash

/usr/bin/bettercap -version | grep 'bettercap v' > /dev/null
if [ $? -eq 0 ];
then
        exit 0
else
        exit 1
fi
