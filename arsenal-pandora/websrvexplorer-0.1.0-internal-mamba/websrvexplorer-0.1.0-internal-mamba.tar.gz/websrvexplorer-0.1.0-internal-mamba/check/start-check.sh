#!/bin/bash

/opt/micromamba/envs/automate/bin/python -W ignore -u /var/lib/pandora/sys/scripts/pandora/explorer/webserver.py | grep 'WEBSRVExplorer: error: the following arguments are required' > /dev/null
if [ $? -eq 0 ];
then
        exit 0
else
        exit 1
fi
