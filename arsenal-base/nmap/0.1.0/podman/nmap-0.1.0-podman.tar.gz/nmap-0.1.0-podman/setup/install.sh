#/bin/bash
# Version : 7.95-r10
tag="[PANDORA::ARSENAL]"
journal="pandora-app"
ImageDigest="sha256:164444eaf1b129b9f538b9074200bab016566f309ff030ee1d6f953cda58244e"
ImageName="docker.io/instrumentisto/nmap@${ImageDigest}"

# Install the image
podman pull $ImageName
if [ $? -ne 0 ];
then
	logger -t "$journal" "$tag Installation failed - 'podman pull command' failed"
	exit 1
fi

sleep 1

# Confirm image installation
podman image exists $ImageName
if [ $? -eq 0 ];
then
	logger -t "$journal" "$tag Installation success"
	exit 0
else
	logger -t "$journal" "$tag Installation failed - 'podman image exists' command failed"
	exit 1
fi
