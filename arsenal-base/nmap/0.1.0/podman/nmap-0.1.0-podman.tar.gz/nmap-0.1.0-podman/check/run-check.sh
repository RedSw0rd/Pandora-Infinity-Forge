#!/bin/bash

podman run --rm -it --network host --cap-add=NET_RAW instrumentisto/nmap -sS --top-port 10 127.0.0.1 > /dev/null
if [ $? -ne 0 ];
then
        exit 0
else
        exit 1
fi
