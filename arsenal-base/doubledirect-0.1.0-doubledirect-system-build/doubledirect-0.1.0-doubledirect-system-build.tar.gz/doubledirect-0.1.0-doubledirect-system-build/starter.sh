#!/bin/bash

cd "$(dirname "${BASH_SOURCE[0]}")"

if [[ -e "setup/forger.sh" ]]
then
	source "setup/forger.sh"
fi
