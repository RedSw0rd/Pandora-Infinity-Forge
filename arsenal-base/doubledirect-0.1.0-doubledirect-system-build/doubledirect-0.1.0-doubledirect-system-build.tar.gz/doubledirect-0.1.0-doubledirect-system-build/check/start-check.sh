#!/bin/bash

/opt/pandora/binary/doubledirect/doubledirect | grep 'ZIMPERIUM - DoubleDirect' > /dev/null
if [ $? -eq 0 ];
then
        exit 0
else
        exit 1
fi
