#!/bin/bash

/opt/micromamba/envs/kerbrute/bin/python -W ignore -u /opt/micromamba/envs/kerbrute/bin/kerbrute -v | grep 'Copyright Fortra' > /dev/null
if [ $? -eq 0 ];
then
        exit 0
else
        exit 1
fi
