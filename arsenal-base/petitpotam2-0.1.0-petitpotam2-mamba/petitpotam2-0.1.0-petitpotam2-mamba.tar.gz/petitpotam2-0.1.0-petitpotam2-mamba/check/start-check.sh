#!/bin/bash

/opt/micromamba/envs/petitpotam2/bin/python -W ignore -u /opt/pandora/github/petitpotam2/petitpotam.py --help | grep 'Coerce' > /dev/null
if [ $? -eq 0 ];
then
        exit 0
else
        exit 1
fi
