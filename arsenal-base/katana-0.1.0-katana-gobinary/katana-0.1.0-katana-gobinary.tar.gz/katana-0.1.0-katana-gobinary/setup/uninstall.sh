#!/bin/bash

journal="pandora-app"
tag="[PANDORA::ARSENAL]"

binName="gospider"
binfolder="/opt/pandora/gobinary/gospider"

if [ -f "$binfolder/$binName" ];
then
        rm -f "$binfolder/$binName"
fi

if [ -f "$binfolder/$binName" ];
then
        logger -t "$journal" "$tag Uninstallation failed - 'rm' command failed'"
        exit 1
fi

# Confirm installation success
logger -t "$journal" "$tag Uninstallation success - $binName binary has been successfully removed"
exit 0
