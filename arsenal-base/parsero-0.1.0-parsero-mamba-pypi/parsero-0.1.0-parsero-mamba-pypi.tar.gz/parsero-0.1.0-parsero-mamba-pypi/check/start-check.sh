#!/bin/bash

/opt/micromamba/envs/parsero/bin/python -W ignore -u /opt/micromamba/envs/parsero/bin/parsero --help | grep 'parsero' > /dev/null
if [ $? -eq 0 ];
then
        exit 0
else
        exit 1
fi
