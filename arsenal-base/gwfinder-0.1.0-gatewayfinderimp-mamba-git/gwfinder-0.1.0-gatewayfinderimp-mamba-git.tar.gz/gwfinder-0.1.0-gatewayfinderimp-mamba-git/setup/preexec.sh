#
# UNIT GWFINDER
# Pre-exec script
#
# Collecte MAC address
#
#
#
#

sleep 1
echo -en "\n│ │ |" >> $HDRFILEPATH
echo -en "\n│ │ | Creating MAC list" >> $HDRFILEPATH
echo -en "\n│ │ | pre-command: /usr/sbin/arp-scan -I $INTERFACE -l -r 1 -i 1 -x" >> $HDRFILEPATH
/usr/sbin/arp-scan -I $INTERFACE -l -r 1 -i 1 -x > /var/lib/pandora/tmp/arpscan.tmp 2>/dev/null
echo -en "\n│ │ | MAC address collected. " >> $HDRFILEPATH
echo -en "\n│ │ | DONE." >> $HDRFILEPATH
echo -en "\n│ │" >> $HDRFILEPATH
