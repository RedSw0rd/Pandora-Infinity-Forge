#!/bin/bash

/opt/micromamba/envs/petitpotam/bin/python -W ignore -u /opt/pandora/github/petitpotam/PetitPotam.py --help | grep 'EfsRpcOpenFileRaw' > /dev/null
if [ $? -eq 0 ];
then
        exit 0
else
        exit 1
fi
