#!/bin/bash

/opt/micromamba/envs/shadowcoerce/bin/python -W ignore -u /opt/pandora/github/shadowcoerce/shadowcoerce.py --help | grep 'MS-FSRVP' > /dev/null
if [ $? -eq 0 ];
then
        exit 0
else
        exit 1
fi
