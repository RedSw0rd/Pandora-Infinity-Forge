#!/bin/bash

/opt/micromamba/envs/humble/bin/python -W ignore -u /opt/pandora/github/humble/humble.py --help | grep 'HTTP Headers Analyzer' > /dev/null
if [ $? -ne 0 ];
then
        exit 0
else
        exit 1
fi
