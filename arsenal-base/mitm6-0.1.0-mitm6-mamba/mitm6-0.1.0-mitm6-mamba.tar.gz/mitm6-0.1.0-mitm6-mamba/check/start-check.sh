#!/bin/bash

/opt/micromamba/envs/mitm6/bin/python -W ignore -u /opt/micromamba/envs/mitm6/bin/mitm6 --help | grep 'pwning IPv4 via IPv6' > /dev/null
if [ $? -ne 0 ];
then
        exit 0
else
        exit 1
fi
