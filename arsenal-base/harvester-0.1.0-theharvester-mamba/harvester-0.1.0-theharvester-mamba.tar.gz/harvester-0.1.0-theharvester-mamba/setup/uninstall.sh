#!/bin/bash

envname="/opt/micromamba/envs/theharvester"
tag="[PANDORA::ARSENAL]"
journal="pandora-app"
gitfolder="/opt/pandora/github/theharvester"
micromamba_bin_path="/opt/micromamba/bin/micromamba"

# Remove git folder
if [ -d "gitfolder" ];
then
	rm -rf "gitfolder"
else
	logger -t "$journal" "$tag Git folder '$gitfolder' not found"
fi

# Remove the Micromamba environment
"$micromamba_bin_path" env remove -y -p "$envname"
if [ $? -ne 0 ];
then
	logger -t "$journal" "$tag Uninstallation failed - 'micromamba env remove' command failed"
	exit 1
fi

sleep 1

# Confirm Micromamba environment removal
if ! "$micromamba_bin_path" env list | grep -q "$envname";
then
	logger -t "$journal" "$tag Uninstallation success"
	exit 0
else
	logger -t "$journal" "$tag Uninstallation failed - Micromamba environment '$envname' still found after removal"
	exit 1
fi
