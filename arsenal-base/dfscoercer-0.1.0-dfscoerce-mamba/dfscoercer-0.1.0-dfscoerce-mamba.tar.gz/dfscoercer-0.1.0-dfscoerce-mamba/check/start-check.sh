#!/bin/bash

/opt/micromamba/envs/dfscoerce/bin/python -W ignore -u /opt/pandora/github/dfscoerce/dfscoerce.py --help | grep 'NetrDfsRemoveStdRoot' > /dev/null
if [ $? -eq 0 ];
then
        exit 0
else
        exit 1
fi
