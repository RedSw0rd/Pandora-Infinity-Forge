#!/bin/bash

/opt/micromamba/envs/sublist3r/bin/python -W ignore -u /opt/pandora/github/sublist3r/sublist3r.py | grep 'Aboul-Ela' > /dev/null
if [ $? -eq 0 ];
then
        exit 0
else
        exit 1
fi
