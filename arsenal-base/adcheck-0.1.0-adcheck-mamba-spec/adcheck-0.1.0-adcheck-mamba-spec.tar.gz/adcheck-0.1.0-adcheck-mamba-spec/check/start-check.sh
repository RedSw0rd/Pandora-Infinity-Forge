#!/bin/bash

/opt/micromamba/envs/adcheck/bin/python -W ignore -u /opt/micromamba/envs/adcheck/bin/adcheck -h | grep 'Active Directory Security Checker' > /dev/null
if [ $? -eq 0 ];
then
        exit 0
else
        exit 1
fi
