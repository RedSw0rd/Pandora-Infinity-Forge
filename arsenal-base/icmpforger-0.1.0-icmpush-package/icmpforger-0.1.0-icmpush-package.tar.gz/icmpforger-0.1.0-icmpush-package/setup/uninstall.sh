#!/bin/bash

journal="pandora-app"
tag="[PANDORA::ARSENAL]"

name="icmpush"

# Remove the DPKG package
dpkg -r "$name"
if [ $? -ne 0 ]; then
	logger -t "$journal" "$tag Uninstallation failed - 'dpkg -r $name' command failed to remove package '$name'"
	exit 1
fi

# Confirm DPKG package removal
dpkg -l "$name" 2>/dev/null | grep -q "^ii"
if [ $? -eq 0 ];
then
	logger -t "$journal" "$tag Uninstallation failed - Package '$name' still confirmed as installed by dpkg after removal attempt"
	exit 1
else
	logger -t "$journal" "$tag Uninstallation success - Package '$name' has been successfully uninstalled"
	exit 0
fi
