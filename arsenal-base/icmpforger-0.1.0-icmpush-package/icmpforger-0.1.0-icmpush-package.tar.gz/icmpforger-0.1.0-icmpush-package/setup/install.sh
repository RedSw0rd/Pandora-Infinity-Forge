#!/bin/bash

journal="pandora-app"
tag="[PANDORA::ARSENAL]"

name="icmpush"
arch=$(uname -m)
archName=""

if [ "$arch" = "x86_64" ];
then
	archName="amd64"

elif [ "$arch" = "aarch64" ];
then
	archName="arm64"
else
	logger -t "$journal" "$tag Installation failed - Unsupported architecture: $arch"
	exit 1
fi

archiveName="icmpush_2.2-6.2_${archName}.deb"
packagePath=$(dirname "$0")"/package/$archiveName"

#
if [ ! -f "$packagePath" ];
then
	logger -t "$journal" "$tag Installation failed - Package '$packagePath' not found"
	exit 1
fi

dpkg -i "$packagePath"
if [ $? -ne 0 ];
then
	logger -t "$journal" "$tag Installation failed - 'dpkg -i $archiveName' command failed to install the package"
	exit 1
fi

dpkg -l "$name" 2>/dev/null | grep -q "^ii"
if [ $? -ne 0 ];
then
	logger -t "$journal" "$tag Installation failed - Package '$name' not confirmed as installed by dpkg"
	exit 1
fi

# Confirm installation success
logger -t "$journal" "$tag Installation success - Package $archiveName has been successfully installed"
exit 0
