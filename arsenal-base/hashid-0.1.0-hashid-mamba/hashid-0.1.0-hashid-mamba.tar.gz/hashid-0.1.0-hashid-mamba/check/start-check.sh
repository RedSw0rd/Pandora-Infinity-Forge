#!/bin/bash

/opt/micromamba/envs/hashid/bin/python -W ignore -u /opt/micromamba/envs/hashid/bin/hashid --version | grep 'https://github.com/psypanda/hashID' > /dev/null
if [ $? -eq 0 ];
then
        exit 0
else
        exit 1
fi
