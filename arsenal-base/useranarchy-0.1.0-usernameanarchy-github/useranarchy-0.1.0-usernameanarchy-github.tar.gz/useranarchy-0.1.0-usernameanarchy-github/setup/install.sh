#!/bin/bash

envname="usernameanarchy"
tag="[PANDORA::ARSENAL]"
journal="pandora-app"

# GIT CONFIG
gitrepo="https://github.com/urbanadventurer/username-anarchy.git"
gitfolder="/opt/pandora/github/usernameanarchy"
gitbranch="v0.6"

#
currentdir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Cloning
git clone --branch "$gitbranch" --depth 1 --single-branch "$gitrepo" "$gitfolder" >/dev/null 2>&1
if [ $? -ne 0 ];
then
        logger -t "$journal" "$tag Installation failed - 'git clone' command failed"
        exit 1
fi

sleep 1

#
# EXTRA
#
#
#

if [ -f "$currentdir/format-plugins.rb" ];
then
	cp "$currentdir/format-plugins.rb" "$gitfolder/format-plugins.rb"
fi
