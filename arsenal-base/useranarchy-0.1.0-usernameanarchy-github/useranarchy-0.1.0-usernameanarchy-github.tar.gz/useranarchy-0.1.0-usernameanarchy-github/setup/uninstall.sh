#!/bin/bash

envname="/opt/micromamba/envs/usernameanarchy"
tag="[PANDORA::ARSENAL]"
journal="pandora-app"
gitfolder="/opt/pandora/github/usernameanarchy"

# Remove git folder
if [ -d "$gitfolder" ];
then
	rm -rf "$gitfolder"
	logger -t "$journal" "$tag Uninstallation success"
	exit 0
else
	logger -t "$journal" "$tag Git folder '$gitfolder' not found"
	exit 1
fi
