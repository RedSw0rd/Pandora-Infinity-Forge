#!/bin/bash

/opt/pandora/github/usernameanarchy/username-anarchy -h | grep 'Andrew Horton (urbanadventurer)' > /dev/null
if [ $? -eq 0 ];
then
        exit 0
else
        exit 1
fi
