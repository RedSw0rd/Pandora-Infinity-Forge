#!/bin/bash

/opt/micromamba/envs/pret/bin/python -W ignore -u /opt/pandora/github/pret/pret.py --help | grep 'printer' > /dev/null
if [ $? -eq 0 ];
then
        exit 0
else
        exit 1
fi
