#!/bin/bash

/opt/micromamba/envs/pret/bin/python -W ignore -u /opt/pandora/github/PRET/pret.py --help | grep 'printer' > /dev/null
if [ $? -ne 0 ];
then
        exit 0
else
        exit 1
fi
