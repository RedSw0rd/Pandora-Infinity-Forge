#!/bin/bash

/opt/micromamba/envs/lfimap/bin/python -W ignore -u /opt/miniconda3/envs/lfimap/bin/lfimap -h | grep 'by @h4nsmach1ne' > /dev/null
if [ $? -eq 0 ];
then
        exit 0
else
        exit 1
fi
