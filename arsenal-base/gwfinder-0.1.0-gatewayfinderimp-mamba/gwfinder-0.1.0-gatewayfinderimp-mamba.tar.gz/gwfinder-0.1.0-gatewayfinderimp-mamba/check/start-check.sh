#!/bin/bash

/opt/micromamba/envs/gatewayfinderimp/bin/python -W ignore -u /opt/pandora/github/gatewayfinderimp/gateway-finder-imp.py -h | grep 'Gateway Finder Improved' > /dev/null
if [ $? -eq 0 ];
then
        exit 0
else
        exit 1
fi
