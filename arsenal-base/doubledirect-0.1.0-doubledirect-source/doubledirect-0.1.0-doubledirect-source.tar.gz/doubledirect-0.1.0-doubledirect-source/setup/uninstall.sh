#!/bin/bash

journal="pandora-app"
tag="[PANDORA::ARSENAL]"

name="doubledirect"
basePath="/opt/pandora/binary"
binaryPath="$basePath/$name/$name"

#
if [ ! -f "$binaryPath" ];
then
        logger -t "$journal" "$tag Uninstallation info - Binary '$binaryPath' not found, no removal needed."
        exit 0
fi

#
rm -f "$binaryPath"
if [ $? -ne 0 ];
then
        logger -t "$journal" "$tag Uninstallation failed - 'rm' command failed to remove binary '$binaryPath'"
        exit 1
fi

rmdir "$basePath/$name" 2>/dev/null

#
if [ ! -f "$binaryPath" ];
then
        logger -t "$journal" "$tag Uninstallation success - Binary '$name' has been successfully uninstalled."
        exit 0
else
        logger -t "$journal" "$tag Uninstallation failed - Binary '$name' still found after removal attempt."
        exit 1
fi
