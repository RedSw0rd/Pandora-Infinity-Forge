#!/bin/bash

journal="pandora-app"
tag="[PANDORA::ARSENAL]"

name="doubledirect"
source="doubledirect.cpp"
sourcepath=$(dirname "$0")"../source/$source"
basepath="/opt/pandora/binary/"

#
if [ ! -f "$sourcepath" ];
then
        logger -t "$journal" "$tag Installation failed - Source file '$sourcepath' not found"
        exit 1
fi

mkdir -p "$basepath/$name"
if [ $? -ne 0 ];
then
        logger -t "$journal" "$tag Installation failed - 'mkdir $basepath/$name' command failed"
        exit 1
fi

g++ "$sourcepath" -o "$basepath/$name/$name" -lcrafter
if [ $? -ne 0 ];
then
        logger -t "$journal" "$tag Installation failed - Compilationfailed"
        exit 1
fi

# Confirm installation success
logger -t "$journal" "$tag Installation success - '$name' binary installed to '$basepath/$name'"
exit 0
