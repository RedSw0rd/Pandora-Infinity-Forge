#!/bin/bash

/opt/micromamba/envs/pywsus/bin/python -W ignore -u /opt/pandora/github/pywsus/pywsus.py -h | grep 'PsExec64.exe' > /dev/null
if [ $? -ne 0 ];
then
        exit 0
else
        exit 1
fi
