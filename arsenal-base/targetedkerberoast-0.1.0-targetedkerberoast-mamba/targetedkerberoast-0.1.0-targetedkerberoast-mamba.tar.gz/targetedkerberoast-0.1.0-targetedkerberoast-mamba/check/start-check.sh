#!/bin/bash

/opt/micromamba/envs/targetedkerberoast/bin/python -W ignore -u /opt/pandora/github/targetedKerberoast/targetedKerberoast.py -h | grep 'operate targeted Kerberoasting' > /dev/null
if [ $? -eq 0 ];
then
        exit 0
else
        exit 1
fi
