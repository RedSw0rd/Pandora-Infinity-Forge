#!/bin/bash

/opt/micromamba/envs/wafw00f/bin/python -W ignore -u /opt/micromamba/envs/wafw00f/bin/wafw00f --help | grep 'http://www.victim.org/' > /dev/null
if [ $? -ne 0 ];
then
        exit 0
else
        exit 1
fi
