#!/bin/bash

/opt/micromamba/envs/seth/bin/python -W ignore -u /opt/pandora/github/seth/seth.py --help | grep 'Adrian Vollmer' > /dev/null
if [ $? -eq 0 ];
then
        exit 0
else
        exit 1
fi
