#!/bin/bash

/opt/pandora/gobinary/kerbrute/kerbrute -h | grep 'Ronnie Flathers' > /dev/null
if [ $? -eq 0 ];
then
        exit 0
else
        exit 1
fi
