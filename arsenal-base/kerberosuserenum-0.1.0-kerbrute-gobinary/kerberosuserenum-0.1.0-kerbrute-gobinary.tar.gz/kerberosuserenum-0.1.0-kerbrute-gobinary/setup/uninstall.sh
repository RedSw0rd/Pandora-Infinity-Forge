#!/bin/bash

journal="pandora-app"
tag="[PANDORA::ARSENAL]"

binName="kerbrute"
binfolder="/opt/pandora/gobinary/kerbrute"

if [ -f "$binfolder/$binName" ];
then
        rm -f "$binfolder/$binName"
        rm -rf "$binfolder"
fi

if [ -f "$binfolder/$binName" ];
then
        logger -t "$journal" "$tag Uninstallation failed - 'rm' command failed'"
        exit 1
fi

# Confirm uninstallation success
logger -t "$journal" "$tag Uninstallation success - $binName binary has been successfully removed"
exit 0
