#!/bin/bash

journal="pandora-app"
tag="[PANDORA::ARSENAL]"

binName="kerbrute"
binVersion="v0.1.1"
urlVersion="v0.1.1"
binfolder="/opt/pandora/gobinary/$binName"
tempArchive="/tmp/download.tar.gz"

arch=$(uname -m)
archUrl=""

if [ "$arch" = "x86_64" ];
then
        archUrl="x86_64"

elif [ "$arch" = "aarch64" ];
then
        archUrl="arm64"
else
        logger -t "$journal" "$tag Installation failed - Unsupported architecture: $arch"
        exit 1
fi

binUrl="https://github.com/0xZDH/kerbrute/releases/download/${binVersion}/kerbrute_${urlVersion}_Linux_${archUrl}.tar.gz"

#
if [ ! -d "$binfolder" ];
then
        mkdir -p "$binfolder"
fi

if [ ! -d "$binfolder" ];
then
        logger -t "$journal" "$tag Installation failed - Could not create binary folder '$binfolder'"
        exit 1
fi

# Download the archive silently
wget -q "$binUrl" -O "$tempArchive"
if [ $? -ne 0 ];
then
        logger -t "$journal" "$tag Installation failed - 'wget' command failed to download '$binUrl'"
        exit 1
fi

mkdir -p /tmp/untar_kerbrute
tar -xzf "$tempArchive" -C /tmp/untar_kerbrute
if [ $? -ne 0 ];
then
        logger -t "$journal" "$tag Installation failed - 'tar' command failed for '$tempArchive'"

        # Clean up downloaded file even if untar fails
        rm -f "$tempArchive"
        exit 1
fi

mv /tmp/untar_kerbrute/$binName "$binfolder/$binName"
if [ $? -ne 0 ];
then
        logger -t "$journal" "$tag Installation failed - 'mv' command failed to copy $binName binary to '$binfolder'"

        # Clean up
        rm -f "$tempArchive" "/tmp/untar_kerbrute/$binName"
        exit 1
fi

chmod +x "$binfolder/$binName"
if [ $? -ne 0 ];
then
        logger -t "$journal" "$tag WARNING - 'chmod' command failed for '$binfolder/$binName' - Run the command as root : chmod +x '$binfolder/$binName'"
fi

mv /tmp/untar_kerbrute/LICENSE "$binfolder/"

# Clean
rm -f "$tempArchive"
rm -rf /tmp/untar_kerbrute

# Confirm installation success
logger -t "$journal" "$tag Installation success - $binName binary installed to '$binfolder'"
exit 0
