#!/bin/bash

/opt/micromamba/envs/dnschef/bin/python -W ignore -u /opt/pandora/github/dnschef/dnschef.py -h | grep 'iphelix@thesprawl.org' > /dev/null
if [ $? -eq 0 ];
then
        exit 0
else
        exit 1
fi
