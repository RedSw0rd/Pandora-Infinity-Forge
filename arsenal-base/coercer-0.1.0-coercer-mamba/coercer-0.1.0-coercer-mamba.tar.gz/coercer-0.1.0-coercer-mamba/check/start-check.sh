#!/bin/bash

/opt/micromamba/envs/coercer/bin/python -W ignore -u /opt/micromamba/envs/coercer/bin/coercer -h | grep 'by @podalirius_' > /dev/null
if [ $? -eq 0 ];
then
        exit 0
else
        exit 1
fi
