#!/bin/bash

/usr/bin/icmpush -V | grep 'by Slayer' > /dev/null
if [ $? -eq 0 ];
then
        exit 0
else
        exit 1
fi
