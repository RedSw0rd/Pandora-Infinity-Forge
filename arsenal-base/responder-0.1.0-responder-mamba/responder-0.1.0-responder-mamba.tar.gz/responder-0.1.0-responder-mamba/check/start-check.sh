#!/bin/bash

/opt/micromamba/envs/responder/bin/python /opt/pandora/github/Responder/Responder.py --version | grep 'NBT-NS, LLMNR & MDNS Responder' > /dev/null
if [ $? -ne 0 ];
then
        exit 0
else
        exit 1
fi
