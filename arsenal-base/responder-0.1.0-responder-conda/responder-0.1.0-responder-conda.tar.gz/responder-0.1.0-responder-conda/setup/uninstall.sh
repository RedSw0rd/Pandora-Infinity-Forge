#!/bin/bash

envname="responder"
tag="[PANDORA::ARSENAL]"
journal="pandora-app"
gitfolder="/opt/pandora/github/responder"
conda_bin_path="/opt/miniconda3/bin/conda"

# Remove git folder
if [ -d "gitfolder" ];
then
	rm -rf "gitfolder"
else
	logger -t "$journal" "$tag Git folder '$gitfolder' not found"
fi


# Remove the Conda environment
"$conda_bin_path" env remove -n "$envname"
if [ $? -ne 0 ];
then
	logger -t "$journal" "$tag Uninstallation failed - 'conda env remove' command failed"
	exit 1
fi

sleep 1

# Confirm Conda environment removal
if ! "$conda_bin_path" env list | grep -q "$envname";
then
	logger -t "$journal" "$tag Uninstallation success"
	exit 0
else
	logger -t "$journal" "$tag Uninstallation failed - Conda environment '$envname' still found after removal"
	exit 1
fi
