#!/bin/bash

/opt/miniconda3/envs/sslyze/bin/python -W ignore -u /opt/miniconda3/envs/sslyze/bin/sslyze -h | grep 'SSLyze version 6.1.0' > /dev/null
if [ $? -ne 0 ];
then
        exit 0
else
        exit 1
fi
