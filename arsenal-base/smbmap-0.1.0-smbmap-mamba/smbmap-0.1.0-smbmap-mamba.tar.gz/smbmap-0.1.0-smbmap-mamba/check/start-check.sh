#!/bin/bash

/opt/micromamba/envs/smbmap/bin/python -W ignore -u /opt/micromamba/envs/smbmap/bin/smbmap | grep 'ShawnDEvans' > /dev/null
if [ $? -ne 0 ];
then
        exit 0
else
        exit 1
fi
