#!/bin/bash

/opt/micromamba/envs/sshmitm/bin/python -W ignore -u /opt/micromamba/envs/sshmitm/bin/ssh-mitm --version | grep 'SSH-MITM' > /dev/null
if [ $? -eq 0 ];
then
        exit 0
else
        exit 1
fi
