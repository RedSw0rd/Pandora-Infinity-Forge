#!/bin/bash

envname="credslayer"
tag="[PANDORA::ARSENAL]"
journal="pandora-app"

# MICROMAMBA
currentdir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
php_file="$currentdir/$envname.php"
mamba_env_file="$currentdir/config.yaml"
mamba_bin_path="/opt/micromamba/bin/micromamba"

# Verify the presence of the environment configuration file
if [ ! -f "$mamba_env_file" ];
then
        logger -t "$journal" "$tag Installation failed - Micromamba environment file '$mamba_env_file' not found"
        exit 1
fi

# Install the Micromamba environment from the file
"$mamba_bin_path" env create -y -f "$mamba_env_file" >/dev/null 2>&1
if [ $? -ne 0 ];
then
        logger -t "$journal" "$tag Installation failed - 'micromamba env create' command failed"
        exit 1
fi

sleep 1

# Confirm Micromamba environment installation
if "$mamba_bin_path" env list | grep -q "$envname";
then
        logger -t "$journal" "$tag Installation success"
else
        logger -t "$journal" "$tag Installation failed - Micromamba environment '$envname' not found after creation"
        exit 1
fi


###########################################################################
# INTEGRATION
###########################################################################

#
if [ -d "/var/lib/pandora/log/output/$envname" ];
then
        echo "|!| The folder /var/lib/pandora/log/output/$envname already exists"
else
        mkdir /var/lib/pandora/log/output/$envname
fi

# MOVE THE PHP SCRIPT
echo "|+| Copying files"
mv $php_file /var/www/pandora/usr/ext/

#
chown www-data: "/var/lib/pandora/log/output/$envname"
chown -R www-data: /var/www/pandora/usr/ext/
