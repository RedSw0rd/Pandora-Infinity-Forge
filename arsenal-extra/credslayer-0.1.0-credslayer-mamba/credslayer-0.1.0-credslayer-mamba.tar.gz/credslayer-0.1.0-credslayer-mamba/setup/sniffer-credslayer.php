<?php
/*
|
| Filename    : sniffer-credslayer.php
| Description :
| Author      : Fadi KELAJIAN
| Copyright   : (c) 'Fadi KELAJIAN - redsword.io' All Rights Reserved
|
|
|
|
|
|
|
|
*/

$DOCROOT = $_SERVER['DOCUMENT_ROOT'];
require_once("$DOCROOT/sys/inc/php/vars.php");
require_once("$LIB_DIR_PATH/sys.php");
require_once("$LIB_DIR_PATH/chk.php");
require_once("$LIB_DIR_PATH/lsg.php");
require_once("$LIB_DIR_PATH/tlz.php");
check_login();

$PROGNAME = "credslayer";
$CODENAME = "CREDSLAYER";
$CLASS = "PASSIVE";

$u = unit_get_active_blade($CODENAME);
$u_p = unit_get_path($CODENAME);
$u_m = unit_preload($CODENAME, $CLASS);
$totrun = task_count($CODENAME);

$intromsg = "";
$errormsg = "";
$binpath = $u['toolpath'];
$lastrun = $u_p['lastrun'];
$unitlog = $u_p['unitlog'];
$pidfile = $u_p['pidfile'];
$loadfile = $u_p['loadfile'] ;
$initmsg = $u_m['initmsg'];
$initerror = $u_m['initerror'];

if (isset($_POST['submit']))
{
        $actiontodo = $_POST['submit'] ;
        if ($actiontodo === "SNIFF")
        {
                if (isset($_POST['interface']) && !empty($_POST['interface']))
                {
                        $interface = $_POST['interface'];
                        if (check_interface($interface))
                        {
                                $cmdarg = unit_build_cmdline($CODENAME, $_POST);

                                if (is_array($cmdarg))
                                {
                                        $cmdline = "$binpath ".unit_convert_cmdline($cmdarg);
                                }
                                else $errormsg = $cmdarg;

                                // RUN
                                if(empty($errormsg) && empty($initerror) && !file_exists($loadfile))
                                {
                                        task_load("$PROGNAME", "$CODENAME", base64_encode($cmdline), "", "", "", "", "", "", "$CLASS", "$CODENAME", "$interface", "", "", "", "", "", "", "", "", "", "$interface", "", "", "0", "99", "{$_SESSION["username"]}", "{$_SESSION["NamespaceID"]}", "");
                                        unit_exec("$CODENAME", "$unitlog");
                                }
                        }
                        else $errormsg="$ERROR_INTERFACE_NOT_VALID" ;
                }
                else $errormsg="$ERROR_INTERFACE_NOT_SPECIFIED" ;
        }
}

if (file_exists($pidfile)) $action="STOP" ;
else $action="SNIFF" ;
?>
<form method='POST' enctype='multipart/form-data' autocomplete='off'>
        <div class='pdr-toolz-header-frame <?php print $transparency_second_sub_class; ?> fadein'>
                <table>
                        <tr>
                                <td class='text'>STATUS : <span id='status'></span></td>
                                <td class='time'>TIME : <span class='timeval' id='time'>00:00:00</span></td>
                                <td class='icon'>
                                        <a href='javascript:void(0);' onclick="toggleVisibility('term');"><img class='shine' src='<?php print $IMAGE_UNIT_DIR; ?>/console.png'/></a>
                                        <a href='javascript:void(0);' onclick="toggleVisibility('param');"><img class='shine' src='<?php print $IMAGE_UNIT_DIR; ?>/parameter.png'/></a>
                                        <a href='javascript:void(0);' onclick="toggleVisibility('lastrun');"><img class='shine' src='<?php print $IMAGE_UNIT_DIR; ?>/lastrun.png'/></a>
                                        <a href='javascript:void(0);' onclick="toggleVisibility('history');"><img class='shine' src='<?php print $IMAGE_UNIT_DIR; ?>/history.png'/></a>
                                        <a href='javascript:void(0);' onclick="toggleVisibility('info');"><img class='shine' src='<?php print $IMAGE_UNIT_DIR; ?>/info.png'/></a>
                                        <a href="javascript:void(0);" onclick="OpenTool('/sys/inc/php/popup/unity-console.php?n=<?php print $CODENAME; ?>', '<?php print $CODENAME; ?>', <?php print $unit_console_width; ?>, <?php print $unit_console_heigth; ?>);return false;"><img id='isw' class='shine' src='<?php print $IMAGE_UNIT_DIR; ?>/detach.png'/></a>
                                </td>
                        </tr>
                </table>
        </div>
        <div class='pdr-toolz-container'>
                <div id='term' class='term <?php print $transparency_second_sub_class; ?> fadein'>
                        <div class='termframe'>
                                <div id='output' class='output <?php print "$console_class $console_font_size_class"; ?>'><?php
                                unity_reader_pid_tracker($PROGNAME, $CODENAME, "SNIFF", "STOP", $errormsg, $intromsg, $initerror, $initmsg);
                                ?>
                                </div>
                        </div>
                </div>
                <div id='param' class='param <?php print $transparency_second_sub_class; ?> fadein' style='display:none;'>
                        <?php unit_print_form($CODENAME); ?>
                </div>
                <div id='lastrun' class='lastrun <?php print $transparency_second_sub_class; ?> fadein' style='display:none;'>
                        <div class='frame'>
                                <div class='output <?php print "$console_class $console_font_size_class"; ?>'><?php display_lastrun($CODENAME); ?></div>
                        </div>
                </div>
                <div id='history' class='history <?php print $transparency_second_sub_class; ?> fadein' style='display:none;'>
                        <div id='history-output' class='history-output'>
                                <?php display_history($CODENAME); ?>
                        </div>
                </div>
                <div id='info' class='info <?php print $transparency_second_sub_class; ?> fadein' style='display:none;'>
                        <div id='info-output' class='info-output'>
                                <script type='text/javascript'>
                                $.ajax({
                                        url: '/sys/inc/php/page/toolzinfo.php?tlz=<?php print $CODENAME; ?>',
                                        type: 'GET',
                                        success: function(result){
                                                $('#info-output').html(result);
                                        }
                                });
                                </script>
                        </div>
                </div>
        </div>
        <div class='pdr-toolz-footer-container'>
                <div class='left <?php print $transparency_second_sub_class; ?> fadein'>
                        <table><tr><td class='total'>TOTAL RUN : <?php print "<font class='$glow_color_class'>$totrun</font>"; ?></td></tr></table>
                </div>
                <div class='right <?php print $transparency_second_sub_class; ?> fadein'>
                        <table><tr><td class='text'><input class='toolz-run' id='action' type='submit' value='<?php echo $action ; ?>' name='submit'></td></tr></table>
                </div>
        </div>
</form>
<?php
if (isset($_POST['submit']))
{
        if ($_POST['submit']==="STOP")
        {
                file_put_contents($loadfile, "0");
                shell_exec_sudo("/usr/bin/php $UNITY_SCRIPT_DIR_PATH/unit-killer.php -c $CODENAME >> $unitlog 2>&1 &");
        }
}
?>
