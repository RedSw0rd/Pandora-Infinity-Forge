#!/bin/bash

/opt/micromamba/envs/credslayer/bin/python -W ignore -u /opt/micromamba/envs/credslayer/bin/credslayer -h 2>/dev/null | grep 'Helps you find credentials' > /dev/null
if [ $? -eq 0 ];
then
        exit 0
else
        exit 1
fi
