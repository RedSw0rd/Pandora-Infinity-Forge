#!/bin/bash

toolname="credslayer"
envname="/opt/micromamba/envs/credslayer"
php_file="credslayer.php"
tag="[PANDORA::ARSENAL]"
journal="pandora-app"
micromamba_bin_path="/opt/micromamba/bin/micromamba"

#
if [ -d "/var/lib/pandora/log/output/$toolname" ];
then
	rm -rf /var/lib/pandora/log/output/$toolname
fi

#
if [ -e "/var/www/pandora/usr/ext/$php_file" ];
then
	rm /var/www/pandora/usr/ext/$php_file
fi

# Remove the Micromamba environment
"$micromamba_bin_path" env remove -y -p "$envname"
if [ $? -ne 0 ];
then
        logger -t "$journal" "$tag Uninstallation failed - 'micromamba env remove' command failed"
        exit 1
fi

sleep 1

# Confirm Micromamba environment removal
if ! "$micromamba_bin_path" env list | grep -q "$envname";
then
        logger -t "$journal" "$tag Uninstallation success"
        exit 0
else
        logger -t "$journal" "$tag Uninstallation failed - Micromamba environment '$envname' still found after removal"
        exit 1
fi
