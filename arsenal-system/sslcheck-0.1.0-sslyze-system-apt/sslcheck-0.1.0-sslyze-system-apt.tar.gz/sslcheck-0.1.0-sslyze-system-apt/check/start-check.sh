#!/bin/bash

/usr/bin/sslyze -h | grep 'SSLyze version' > /dev/null
if [ $? -eq 0 ];
then
        exit 0
else
        exit 1
fi
