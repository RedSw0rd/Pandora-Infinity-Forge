#!/bin/bash

/usr/sbin/mdk3 --help | grep 'Yeah, well, whatever' > /dev/null
if [ $? -ne 0 ];
then
        exit 0
else
        exit 1
fi
