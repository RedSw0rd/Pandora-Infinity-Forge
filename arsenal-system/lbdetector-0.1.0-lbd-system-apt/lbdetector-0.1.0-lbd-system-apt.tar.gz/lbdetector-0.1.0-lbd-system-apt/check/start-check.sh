#!/bin/bash

/usr/bin/lbd | grep 'load balancing detector' > /dev/null
if [ $? -eq 0 ];
then
        exit 0
else
        exit 1
fi
