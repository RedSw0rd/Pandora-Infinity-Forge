#!/bin/bash

/usr/sbin/hping3 --version | grep 'hping3' > /dev/null
if [ $? -eq 0 ];
then
        exit 0
else
        exit 1
fi
