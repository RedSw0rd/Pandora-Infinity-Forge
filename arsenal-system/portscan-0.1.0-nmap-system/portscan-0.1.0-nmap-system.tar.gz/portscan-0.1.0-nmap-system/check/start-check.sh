#!/bin/bash

/usr/bin/nmap -V | grep 'Nmap version' > /dev/null
if [ $? -ne 0 ];
then
        exit 0
else
        exit 1
fi
