#!/bin/bash

/usr/bin/bloodhound-python | grep 'for BloodHound LEGACY' > /dev/null
if [ $? -eq 0 ];
then
        exit 0
else
        exit 1
fi
