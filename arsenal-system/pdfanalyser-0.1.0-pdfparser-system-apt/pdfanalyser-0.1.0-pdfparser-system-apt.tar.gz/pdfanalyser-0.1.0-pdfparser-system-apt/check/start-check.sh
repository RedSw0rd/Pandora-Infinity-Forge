#!/bin/bash

/usr/bin/pdf-parser --version | grep '/pdf-parser' > /dev/null
if [ $? -eq 0 ];
then
        exit 0
else
        exit 1
fi
