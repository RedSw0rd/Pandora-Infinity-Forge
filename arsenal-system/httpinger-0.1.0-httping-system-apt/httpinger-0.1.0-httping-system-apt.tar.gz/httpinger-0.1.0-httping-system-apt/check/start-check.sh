#!/bin/bash

/usr/bin/httping -V 2>/dev/stdout | grep 'HTTPing' > /dev/null
if [ $? -eq 0 ];
then
        exit 0
else
        exit 1
fi
