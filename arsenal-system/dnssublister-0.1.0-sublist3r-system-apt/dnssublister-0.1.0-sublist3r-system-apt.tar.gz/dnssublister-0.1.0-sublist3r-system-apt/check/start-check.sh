#!/bin/bash

/usr/bin/sublist3r | grep 'Aboul-Ela' > /dev/null
if [ $? -eq 0 ];
then
        exit 0
else
        exit 1
fi
