#!/bin/bash

/usr/sbin/airodump-ng | grep 'https://www.aircrack-ng.org' > /dev/null
if [ $? -eq 0 ];
then
        exit 0
else
        exit 1
fi
