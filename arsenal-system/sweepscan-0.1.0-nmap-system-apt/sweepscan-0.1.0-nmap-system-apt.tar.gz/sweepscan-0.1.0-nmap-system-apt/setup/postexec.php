<?php
/*
|
| Script de post traitement pour convertir
| le fichier xml en simple liste d'IP.
|
| Apres le traitement, le resultat doit etre
| ecrit dans un fichier au format suivant :
|
| unitname-taskID.list
|
| Ce format permettra au traitement de post execution
| de le detecter pour le traiter et l'enregistrer
|
|
|
|
*/

$NMAP_SWEEPSCAN_XML_FILE = "$INPUT_LIST_DIR_PATH/sweepscan/sweepscan-$PANDORA_TASKID.xml";
$NMAP_SWEEPSCAN_LIST = "$INPUT_LIST_DIR_PATH/sweepscan/sweepscan-$PANDORA_TASKID.list";

if (is_file($NMAP_SWEEPSCAN_XML_FILE))
{
        if (filesize($NMAP_SWEEPSCAN_XML_FILE) > 0)
        {
                $content = "";
                $line_arr = array();
                $xml = simplexml_load_string(file_get_contents($NMAP_SWEEPSCAN_XML_FILE));

                foreach ($xml->host as $h)
                {
                        $t = $h->address['addr'] ;
                        if (!empty($t))
                        {
                                $content .= "$t\n";
                        }
                }

                if (!empty($content))
                {
                        // WRITE RESULT
                        file_put_contents($NMAP_SWEEPSCAN_LIST, $content);
                }
        }

        unlink($NMAP_SWEEPSCAN_XML_FILE);
}
