#!/bin/bash

/usr/sbin/p0f -L | grep 'Michal Zalewski' > /dev/null
if [ $? -eq 0 ];
then
        exit 0
else
        exit 1
fi
