#!/bin/bash

/usr/bin/cupp --version | grep 'j0rgan@remote-exploit.org' > /dev/null
if [ $? -eq 0 ];
then
        exit 0
else
        exit 1
fi
