#!/bin/bash

/usr/bin/impacket-wmiexec | grep 'Copyright Fortra' > /dev/null
if [ $? -eq 0 ];
then
        exit 0
else
        exit 1
fi
