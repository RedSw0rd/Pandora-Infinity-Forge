#!/bin/bash

/usr/bin/subfinder -h | grep 'Subfinder is a subdomain discovery' > /dev/null
if [ $? -eq 0 ];
then
        exit 0
else
        exit 1
fi
