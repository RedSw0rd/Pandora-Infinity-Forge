#!/bin/bash

/usr/bin/responder-RunFinger -h | grep 'responder-RunFinger' > /dev/null
if [ $? -eq 0 ];
then
        exit 0
else
        exit 1
fi
