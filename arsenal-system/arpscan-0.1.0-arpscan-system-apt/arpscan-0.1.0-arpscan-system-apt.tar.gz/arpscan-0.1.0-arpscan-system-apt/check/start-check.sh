#!/bin/bash

/usr/sbin/arp-scan -V | grep 'Roy Hills' > /dev/null
if [ $? -eq 0 ];
then
        exit 0
else
        exit 1
fi
