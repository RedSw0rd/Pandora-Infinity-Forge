#!/bin/bash

/usr/bin/humble --help | grep 'HTTP Headers Analyzer' > /dev/null
if [ $? -eq 0 ];
then
        exit 0
else
        exit 1
fi
