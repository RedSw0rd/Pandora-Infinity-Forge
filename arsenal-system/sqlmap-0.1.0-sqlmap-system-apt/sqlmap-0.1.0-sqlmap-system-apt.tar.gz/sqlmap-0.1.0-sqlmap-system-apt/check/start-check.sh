#!/bin/bash

/usr/bin/sqlmap --help | grep 'sqlmap.org' > /dev/null
if [ $? -eq 0 ];
then
        exit 0
else
        exit 1
fi
