#!/bin/bash

/usr/bin/traceroute --version | grep 'Modern traceroute for Linux' > /dev/null
if [ $? -ne 0 ];
then
        exit 0
else
        exit 1
fi
