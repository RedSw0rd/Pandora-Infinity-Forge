#!/bin/bash

urlcrazy --help | grep 'urbanadventurer' > /dev/null
if [ $? -eq 0 ];
then
        exit 0
else
        exit 1
fi
