#!/bin/bash

/usr/bin/rpcinfo 2>/dev/stdout | grep 'Remote system error' > /dev/null
if [ $? -eq 0 ];
then
        exit 0
else
        exit 1
fi
