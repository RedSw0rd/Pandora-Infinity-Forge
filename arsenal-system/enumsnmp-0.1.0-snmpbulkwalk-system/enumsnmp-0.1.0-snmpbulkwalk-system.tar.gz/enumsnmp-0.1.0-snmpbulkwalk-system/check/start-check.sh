#!/bin/bash

/usr/bin/snmpbulkwalk -V | grep 'NET-SNMP' > /dev/null
if [ $? -eq 0 ];
then
        exit 0
else
        exit 1
fi
