#!/bin/bash

/usr/bin/braa -h | grep 'mtg@elsat.net.pl' > /dev/null
if [ $? -eq 0 ];
then
        exit 0
else
        exit 1
fi
