#!/bin/bash

/usr/bin/joomscan --about | grep 'Mohammad Reza Espargham' > /dev/null
if [ $? -eq 0 ];
then
        exit 0
else
        exit 1
fi
