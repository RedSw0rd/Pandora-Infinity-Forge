#!/bin/bash

/usr/bin/name-that-hash --help 2>/dev/stdout | grep 'From the creator of RustScan and Ciphey' > /dev/null
if [ $? -eq 0 ];
then
        exit 0
else
        exit 1
fi
