#!/bin/bash

/usr/bin/tshark --version | grep 'TShark (Wireshark)' > /dev/null
if [ $? -ne 0 ];
then
        exit 0
else
        exit 1
fi
