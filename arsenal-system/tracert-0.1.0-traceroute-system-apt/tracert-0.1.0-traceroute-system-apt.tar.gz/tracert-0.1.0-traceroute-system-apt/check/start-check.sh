#!/bin/bash

/usr/bin/traceroute --version 2>/dev/stdout | grep 'Modern traceroute for Linux' > /dev/null
if [ $? -eq 0 ];
then
        exit 0
else
        exit 1
fi
