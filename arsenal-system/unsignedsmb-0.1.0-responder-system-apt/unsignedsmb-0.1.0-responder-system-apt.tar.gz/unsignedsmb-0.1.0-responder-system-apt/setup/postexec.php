<?php
/*
|
| Script de post traitement pour generer un fichier d'entree
| contenant uniquement une liste d'IP, a partir du fichier de log brute (RAW).
|
| NOTE:
| L'outil ne propose pas nativement une option pour sauvegarder son resultat
| dans un fichier de son choix. En tant normal, ce type option est utilise pour
| produire un fichier avec l'extension .list afin qu'il soit traite automatiquement.
|
| Dans le cas present, nous allons traiter le fichier log brute et generer nous
| meme un fichier avec l'extension .list.
|
|
| On utilise le champs EXTRA pour recuperer les infos et determiner si le Commander
| a demande la generation de l'input list.
|
| Apres le traitement, le resultat doit etre ecrit dans un fichier au format suivant :
|
| unitname-taskID.list
|
| Comme indique, ce format permettra au gestionnaire de post-execution
| de le detecter pour le traiter et l'enregistrer
|
| Les variables d'environnement ci-dessous sont utilisees:
|
| $PANDORA_RAW_LOG_PATH (chemin vers le fichier log brute)
| $PANDORA_TASKID (Numero de tache d'UNIT)
|
|
|
*/

$db = new SQLite3("$SYS_DB_DIR_PATH/taskman-loader.db");
if($db)
{
        // EXTRAINFO FIELD
        $extrainfo_json = $db->querySingle("SELECT EXTRAINFO FROM TASK_LOADER WHERE CODENAME='UNSIGNEDSMB'");
}
$db->close();

// IF FIELD IS NOT EMPTY SO WE HAVE A PATH
if (isset($extrainfo_json) && !empty($extrainfo_json))
{
        $extrainfo = json_decode($extrainfo_json, true);

        if ($extrainfo['INPUT'] === "ON");
        {
                if ($extrainfo['INPUTSRC'] === "RAW");
                {
                        if (is_file($PANDORA_RAW_LOG_PATH))
                        {
                                $content = "";
                                $INPUT_LIST = "$INPUT_LIST_DIR_PATH/unsignedsmb/unsignedsmb-$PANDORA_TASKID.list";

                                // EXTRACT ALL IP IN THE LOGFILE
                                preg_match_all('/\n\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}/', file_get_contents($PANDORA_RAW_LOG_PATH), $match);
                                foreach ($match[0] as $line)
                                {
                                        if (!empty(trim($line)))
                                        {
                                                $content .= "$line";
                                        }
                                }

                                if (!empty($content))
                                {
                                        // WRITE RESULT
                                        file_put_contents($INPUT_LIST, $content);
                                }
                        }
                }
        }
}
?>
