#!/bin/bash

/usr/bin/wapiti --version | grep '^Wapiti' > /dev/null
if [ $? -eq 0 ];
then
        exit 0
else
        exit 1
fi
