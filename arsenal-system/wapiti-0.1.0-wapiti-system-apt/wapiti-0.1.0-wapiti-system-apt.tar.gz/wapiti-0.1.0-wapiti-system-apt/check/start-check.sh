#!/bin/bash

/usr/bin/wapiti --version | grep 'wapiti-scanner.github.io' > /dev/null
if [ $? -eq 0 ];
then
        exit 0
else
        exit 1
fi
