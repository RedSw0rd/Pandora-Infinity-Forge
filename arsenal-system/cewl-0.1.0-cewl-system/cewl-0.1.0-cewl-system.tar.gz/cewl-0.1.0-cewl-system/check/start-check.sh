#!/bin/bash

/usr/bin/cewl -h | grep 'robin@digi.ninja' > /dev/null
if [ $? -eq 0 ];
then
        exit 0
else
        exit 1
fi
