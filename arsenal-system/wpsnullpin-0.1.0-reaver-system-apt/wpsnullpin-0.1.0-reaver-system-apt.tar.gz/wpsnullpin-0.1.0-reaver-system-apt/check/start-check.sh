#!/bin/bash

/usr/bin/reaver -h 2>/dev/stdout | grep 'Craig Heffner' > /dev/null
if [ $? -eq 0 ];
then
        exit 0
else
        exit 1
fi
