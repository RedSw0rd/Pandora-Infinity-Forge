#!/bin/bash

/usr/bin/ffuf -V | grep 'ffuf version:' > /dev/null
if [ $? -eq 0 ];
then
        exit 0
else
        exit 1
fi
