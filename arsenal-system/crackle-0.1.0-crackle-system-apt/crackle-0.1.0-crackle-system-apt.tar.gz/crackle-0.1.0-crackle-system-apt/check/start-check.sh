#!/bin/bash

/usr/bin/crackle | grep 'Cracks Bluetooth Low Energy encryption' > /dev/null
if [ $? -eq 0 ];
then
        exit 0
else
        exit 1
fi
