#!/bin/bash

/usr/bin/hashid --version | grep 'https://github.com/psypanda/hashID' > /dev/null
if [ $? -eq 0 ];
then
        exit 0
else
        exit 1
fi
