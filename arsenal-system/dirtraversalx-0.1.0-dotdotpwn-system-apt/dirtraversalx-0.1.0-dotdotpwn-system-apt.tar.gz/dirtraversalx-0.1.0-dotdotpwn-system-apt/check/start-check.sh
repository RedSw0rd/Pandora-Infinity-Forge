#!/bin/bash

/usr/bin/dotdotpwn 2>/dev/stdout | grep 'chr1x.sectester.net' > /dev/null
if [ $? -eq 0 ];
then
        exit 0
else
        exit 1
fi
