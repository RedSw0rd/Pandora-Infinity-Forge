#!/bin/bash

/usr/bin/spraykatz --help | grep 'Written by @aas_s3curity' > /dev/null
if [ $? -eq 0 ];
then
        exit 0
else
        exit 1
fi
