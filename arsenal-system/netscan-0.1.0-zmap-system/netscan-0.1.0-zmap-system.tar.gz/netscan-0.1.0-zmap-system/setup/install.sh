#!/bin/bash

envname="system"
packagename="zmap"
tag="[PANDORA::ARSENAL]"
journal="pandora-app"

dpkg -l "$packagename" 2>/dev/null | grep -q "^ii"
if [ $? -eq 0 ];
then
        logger -t "$journal" "$tag Package '$packagename' already installed"
        exit 0
fi

# Install
apt-get install -y "$packagename" >/dev/null 2>&1
if [ $? -ne 0 ];
then
        logger -t "$journal" "$tag Installation failed - 'apt-get install' command failed"
        exit 1
fi

dpkg -l "$packagename" 2>/dev/null | grep -q "^ii"
if [ $? -ne 0 ];
then
        logger -t "$journal" "$tag Installation failed - Package '$packagename' not confirmed as installed by dpkg"
        exit 1
else
        logger -t "$journal" "$tag Installation success"
        exit 0
fi
