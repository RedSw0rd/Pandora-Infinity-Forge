#!/bin/bash

/usr/bin/smtp-user-enum -h | grep 'smtp-user-enum-user-docs.pdf' > /dev/null
if [ $? -eq 0 ];
then
        exit 0
else
        exit 1
fi
