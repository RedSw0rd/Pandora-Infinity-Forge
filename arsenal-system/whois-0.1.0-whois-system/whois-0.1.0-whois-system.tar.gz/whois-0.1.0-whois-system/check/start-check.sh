#!/bin/bash

/usr/bin/whois --version | grep 'whois@linux.it' > /dev/null
if [ $? -eq 0 ];
then
        exit 0
else
        exit 1
fi
