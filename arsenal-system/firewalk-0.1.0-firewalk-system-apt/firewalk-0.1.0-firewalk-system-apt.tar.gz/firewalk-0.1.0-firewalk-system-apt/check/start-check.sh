#!/bin/bash

/usr/sbin/firewalk -v | grep 'gateway ACL scanner' > /dev/null
if [ $? -eq 0 ];
then
        exit 0
else
        exit 1
fi
