#!/bin/bash

/usr/bin/rtl_tcp -h 2>/dev/null | grep 'spectrum server for RTL2832' > /dev/null
if [ $? -ne 0 ];
then
        exit 0
else
        exit 1
fi
