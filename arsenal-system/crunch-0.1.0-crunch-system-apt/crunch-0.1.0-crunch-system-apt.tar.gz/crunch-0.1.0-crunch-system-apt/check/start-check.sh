#!/bin/bash

/usr/bin/crunch 2>/dev/stdout | grep 'wordlist based on criteria' > /dev/null
if [ $? -eq 0 ];
then
        exit 0
else
        exit 1
fi
