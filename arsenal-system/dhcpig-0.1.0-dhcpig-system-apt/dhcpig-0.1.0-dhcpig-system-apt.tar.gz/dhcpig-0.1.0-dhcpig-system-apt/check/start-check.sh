#!/bin/bash

/usr/bin/dhcpig -h 2>/dev/stdout | grep 'enhanced DHCP exhaustion attack' > /dev/null
if [ $? -eq 0 ];
then
        exit 0
else
        exit 1
fi
