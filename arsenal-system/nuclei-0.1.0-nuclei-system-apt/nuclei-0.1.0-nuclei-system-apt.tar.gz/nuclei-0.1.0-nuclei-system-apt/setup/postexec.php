<?php
/*
|
| Insertion des resultats dans une base sqlite.
| L'insertion se fera lorsque le fichier JSON sera present.
| L'utilisateur devra activer l'export JSON.
|
|
|
|
|
*/

if (is_file("$EXPORT_DIR_PATH/nuclei/nuclei.json"))
{
        $date = time();
        $jsonData = file_get_contents("$EXPORT_DIR_PATH/nuclei/nuclei.json");

        $data = json_decode($jsonData, true);

        if (json_last_error() !== JSON_ERROR_NONE)
        {
                die("|ERROR| JSON decoding error : ".json_last_error_msg());
        }

        $db = new SQLite3("$USER_DB_DIR_PATH/nuclei.db");
        if($db)
        {
                $db->busyTimeout(3000);
                foreach ($data as $entry)
                {
                        $templateID = $entry['template-id'] ?? 'N/A';
                        $name = $entry['info']['name'] ?? 'N/A';
                        $severity = $entry['info']['severity'] ?? 'N/A';
                        $matchedAt = $entry['matched-at'] ?? 'N/A';
                        $request = $entry['request'] ?? 'N/A';
                        $response = $entry['response'] ?? 'N/A';
                        $curlcmd = $entry['curl-command'] ?? 'N/A';
                        $host = $entry['host'] ?? 'N/A';
                        $desc = $entry['info']['description'] ?? 'N/A';
                        $impact = $entry['info']['impact'] ?? 'N/A';
                        $reference = implode(', ', $entry['info']['reference'] ?? []);
                        $metadata = $entry['info']['metadata'] ?? [];
                        $product = $metadata['product'] ?? 'N/A';
                        $vendor = $metadata['vendor'] ?? 'N/A';
                        $classification = $entry['info']['classification'] ?? [];
                        $cveId = implode(', ', $classification['cve-id'] ?? []);
                        $cweId = implode(', ', $classification['cwe-id'] ?? []);
                        $cvssMetrics = $classification['cvss-metrics'] ?? 'N/A';
                        $cvssScore = $classification['cvss-score'] ?? 'N/A';
                        $remediation = $entry['info']['remediation'] ?? 'N/A';

                        $smt = $db->prepare("INSERT INTO NUCLEI_VULN (TEMPLATEID, NAME, SEVERITY, MATCHEDAT, REQUEST, RESPONSE, CURLCMD, HOST, DESC, IMPACT, PRODUCT, VENDOR, CVEID, CWEID, CVSSMETRICS, CVSSSCORE, REMEDIATION, REFERENCE, DATE) VALUES (:template, :name, :severity, :matchedat, :request, :response, :curlcmd, :host, :desc, :impact, :product, :vendor, :cveid, :cweid, :cvssmetrics, :cvssscore, :remediation, :reference, :date);");
                        $smt->bindValue(':host', $host, SQLITE3_TEXT);
                        $smt->bindValue(':template', $templateID, SQLITE3_TEXT);
                        $smt->bindValue(':name', $name, SQLITE3_TEXT);
                        $smt->bindValue(':severity', $severity, SQLITE3_TEXT);
                        $smt->bindValue(':matchedat', $matchedAt, SQLITE3_TEXT);
                        $smt->bindValue(':request', $request, SQLITE3_TEXT);
                        $smt->bindValue(':response', $response, SQLITE3_TEXT);
                        $smt->bindValue(':curlcmd', $curlcmd, SQLITE3_TEXT);
                        $smt->bindValue(':desc', $desc, SQLITE3_TEXT);
                        $smt->bindValue(':impact', $impact, SQLITE3_TEXT);
                        $smt->bindValue(':product', $product, SQLITE3_TEXT);
                        $smt->bindValue(':vendor', $vendor, SQLITE3_TEXT);
                        $smt->bindValue(':cveid', $cveId, SQLITE3_TEXT);
                        $smt->bindValue(':cweid', $cweId, SQLITE3_TEXT);
                        $smt->bindValue(':cvssmetrics', $cvssMetrics, SQLITE3_TEXT);
                        $smt->bindValue(':cvssscore', $cvssScore, SQLITE3_TEXT);
                        $smt->bindValue(':remediation', $remediation, SQLITE3_TEXT);
                        $smt->bindValue(':reference', $reference, SQLITE3_TEXT);
                        $smt->bindValue(':date', $date, SQLITE3_INTEGER);
                        $smt->execute();
                }
        }
        $db->close();
        unset($db);
}
?>
