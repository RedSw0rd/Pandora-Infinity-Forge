#!/bin/bash

/usr/bin/nuclei -h 2>/dev/stdout | grep 'template based vulnerability scanner focusing' > /dev/null
if [ $? -eq 0 ];
then
        exit 0
else
        exit 1
fi
