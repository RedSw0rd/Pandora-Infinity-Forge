#!/bin/bash

/usr/bin/binwalk -h | grep 'Craig Heffner' > /dev/null
if [ $? -eq 0 ];
then
        exit 0
else
        exit 1
fi
