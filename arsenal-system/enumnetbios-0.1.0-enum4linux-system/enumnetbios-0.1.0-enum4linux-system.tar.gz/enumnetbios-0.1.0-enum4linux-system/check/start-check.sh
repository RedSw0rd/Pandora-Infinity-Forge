#!/bin/bash

/usr/bin/enum4linux-ng -h | grep 'ENUM4LINUX - next generation' > /dev/null
if [ $? -eq 0 ];
then
        exit 0
else
        exit 1
fi
