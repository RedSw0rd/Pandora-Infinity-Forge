#!/bin/bash

/usr/bin/bettercap --help 2>/dev/stdout | grep 'Usage of' >/dev/null
if [ $? -eq 0 ];
then
        exit 0
else
        exit 1
fi
