#!/bin/bash

/usr/bin/crackmapexec --help | grep 'A swiss army knife for pentesting networks' > /dev/null
if [ $? -eq 0 ];
then
        exit 0
else
        exit 1
fi
