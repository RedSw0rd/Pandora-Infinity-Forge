#!/bin/bash

/usr/bin/wfuzz 2>/dev/null | grep 'The Web Fuzzer' > /dev/null
if [ $? -eq 0 ];
then
        exit 0
else
        exit 1
fi
