#!/bin/bash

/usr/bin/polenum -h | grep 'enum4linux' > /dev/null
if [ $? -eq 0 ];
then
        exit 0
else
        exit 1
fi
