#!/bin/bash

/usr/sbin/cdpr -h | grep 'Cisco Discovery Protocol Reporter' > /dev/null
if [ $? -eq 0 ];
then
        exit 0
else
        exit 1
fi
