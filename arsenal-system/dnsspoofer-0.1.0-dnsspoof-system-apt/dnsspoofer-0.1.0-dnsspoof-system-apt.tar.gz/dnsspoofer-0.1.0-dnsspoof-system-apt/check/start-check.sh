#!/bin/bash

/usr/sbin/dnsspoof -h 2>/dev/stdout | grep 'Version:' > /dev/null
if [ $? -eq 0 ];
then
        exit 0
else
        exit 1
fi
