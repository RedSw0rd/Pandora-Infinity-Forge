#!/bin/bash

/usr/bin/bloodhound-ce-python | grep 'for BloodHound Community Edition' > /dev/null
if [ $? -eq 0 ];
then
        exit 0
else
        exit 1
fi
