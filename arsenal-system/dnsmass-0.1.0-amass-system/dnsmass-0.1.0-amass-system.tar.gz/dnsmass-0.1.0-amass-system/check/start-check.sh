#!/bin/bash

/usr/bin/amass -h 2>/dev/stdout | grep 'Surface Mapping and Asset Discovery' > /dev/null
if [ $? -eq 0 ];
then
        exit 0
else
        exit 1
fi
