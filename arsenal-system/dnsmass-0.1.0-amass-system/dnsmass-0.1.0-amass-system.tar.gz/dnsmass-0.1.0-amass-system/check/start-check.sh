#!/bin/bash

/usr/bin/amass -h 2>/dev/stdout | grep 'Surface Mapping and Asset Discovery' > /dev/null
if [ $? -ne 0 ];
then
        exit 0
else
        exit 1
fi
