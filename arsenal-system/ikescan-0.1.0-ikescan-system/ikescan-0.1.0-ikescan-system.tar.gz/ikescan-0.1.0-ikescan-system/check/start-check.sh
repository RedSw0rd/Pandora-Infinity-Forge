#!/bin/bash

/usr/bin/ike-scan --help 2>/dev/stdout | grep 'royhills/ike-scan' > /dev/null
if [ $? -eq 0 ];
then
        exit 0
else
        exit 1
fi
