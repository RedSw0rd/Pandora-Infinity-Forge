#!/bin/bash

/usr/bin/mitm6 --help | grep 'pwning IPv4 via IPv6' > /dev/null
if [ $? -eq 0 ];
then
        exit 0
else
        exit 1
fi
