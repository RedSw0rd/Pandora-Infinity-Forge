#!/bin/bash

/usr/bin/kal -h | grep 'Joshua Lackey' > /dev/null
if [ $? -eq 0 ];
then
        exit 0
else
        exit 1
fi
