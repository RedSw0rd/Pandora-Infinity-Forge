#!/bin/bash

/usr/bin/wash 2>/dev/stdout | grep 'WiFi Protected Setup Scan Tool' > /dev/null
if [ $? -ne 0 ];
then
        exit 0
else
        exit 1
fi
