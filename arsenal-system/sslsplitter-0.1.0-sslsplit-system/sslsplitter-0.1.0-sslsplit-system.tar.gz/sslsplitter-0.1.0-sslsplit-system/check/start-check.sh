#!/bin/bash

/usr/bin/sslsplit -V  2>/dev/stdout | grep 'Daniel Roethlisberger' > /dev/null
if [ $? -eq 0 ];
then
        exit 0
else
        exit 1
fi
