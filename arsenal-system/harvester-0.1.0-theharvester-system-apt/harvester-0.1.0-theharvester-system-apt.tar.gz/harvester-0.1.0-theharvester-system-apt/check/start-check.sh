#!/bin/bash

/usr/bin/theHarvester --help | grep 'cmartorella@edge-security.com' > /dev/null
if [ $? -eq 0 ];
then
        exit 0
else
        exit 1
fi
