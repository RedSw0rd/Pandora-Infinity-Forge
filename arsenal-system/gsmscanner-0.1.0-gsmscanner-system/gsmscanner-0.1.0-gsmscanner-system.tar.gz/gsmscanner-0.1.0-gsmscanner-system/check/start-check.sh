#!/bin/bash

/usr/bin/grgsm_scanner --help | grep 'Specify the GSM band for the frequency' > /dev/null
if [ $? -ne 0 ];
then
        exit 0
else
        exit 1
fi
