#!/bin/bash

/usr/sbin/zmap --version | grep zmap > /dev/null
if [ $? -eq 0 ];
then
        exit 0
else
        exit 1
fi
