#!/bin/bash

/usr/bin/ssldump -v | grep 'https://github.com/adulau/ssldump/blob/master/CREDITS' > /dev/null
if [ $? -eq 0 ];
then
        exit 0
else
        exit 1
fi
