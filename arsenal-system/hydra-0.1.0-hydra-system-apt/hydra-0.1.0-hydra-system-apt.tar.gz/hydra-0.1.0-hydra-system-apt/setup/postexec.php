<?php
/*
|
| On affiche une notification si un mot de passe a ete decouvert.
| La chaine de caractere normalement presente en cas de succes est :
|
| 'valid password found'
|
|
| Si un fichier de session est detecte alors on creer une entree
| dans notre gesionnaire de session.
|
|
*/

if (is_file($PANDORA_RAW_LOG_PATH))
{
        $fileContent = file_get_contents($PANDORA_RAW_LOG_PATH);
        if (strpos($fileContent, 'valid password found') !== false)
        {
                print "|POST| $codename UNIT > System notification sent to Commander - A password has benn discovered\n";
                sysnotif("CRACKED", "SUCCESS : Account brute force attack successful! A password has been discovered");
        }
}

if (is_file($HYDRA_SESSION_FILE))
{
        // GET INFOS SAVED
        $info = explode("||", file_get_contents("$RUN_DIR_PATH/hydra_session_info.tmp"));
        $ip = $info[0];
        $service = $info[1];
        $port = $info[2];

        // SESSION ID GENERATOR
        $session_hash_id = md5(file_get_contents("$RUN_DIR_PATH/hydra_session_info.tmp"));
        unlink("$RUN_DIR_PATH/hydra_session_info.tmp");

        shell_exec("sudo chown www-data: $HYDRA_SESSION_FILE");
        shell_exec("sudo mv $HYDRA_SESSION_FILE $BRUTE_FORCE_SESSION_DIR_PATH/hydra/$session_hash_id.hydra");

        // CHECK IF DB ENTRY EXIST
        $db = new SQLite3("$USER_DB_DIR_PATH/bruteforce.db");
        if($db)
        {
                $smt = $db->prepare("SELECT ID FROM BRUTE_FORCE_SESSION WHERE IP=:ip AND PORT=:port AND TYPE = 'HYDRA';");
                $smt->bindValue(':ip', $ip, SQLITE3_TEXT);
                $smt->bindValue(':port', $service, SQLITE3_TEXT);
                $r = $smt->execute();
                $row = $r->fetchArray();

                $nid = $row['ID'] ?? '';
        }

        // CREATE NEW ENTRY IN DB
        if (empty($nid))
        {
                print "|POST| $codename UNIT > New HYDRA session created in DB\n";
                print "|POST| $codename UNIT > Session Hash ID: $session_hash_id\n";

                $date = time() ;

                $smt = $db->prepare("INSERT INTO BRUTE_FORCE_SESSION (TYPE, STARTED, IP, PORT, FILEPATH) VALUES ('HYDRA', :date, :ip, :service, :path);");
                $smt->bindValue(':date', $date, SQLITE3_TEXT);
                $smt->bindValue(':ip', $ip, SQLITE3_TEXT);
                $smt->bindValue(':service', $service, SQLITE3_TEXT);
                $smt->bindValue(':path', "$BRUTE_FORCE_SESSION_DIR_PATH/hydra/$session_hash_id.hydra", SQLITE3_TEXT);
                $smt->execute();
        }
        // UPDATE ENTRY
        else
        {
                $date = time() ;
                $db->querySingle("UPDATE BRUTE_FORCE_SESSION SET PAUSED = '$date' WHERE ID='$nid'");
        }
        $db->close();
}
?>
