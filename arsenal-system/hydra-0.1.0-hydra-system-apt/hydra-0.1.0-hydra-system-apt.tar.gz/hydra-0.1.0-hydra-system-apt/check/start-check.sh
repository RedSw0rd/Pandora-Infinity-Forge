#!/bin/bash

/usr/bin/hydra | grep 'by van Hauser/THC' > /dev/null
if [ $? -eq 0 ];
then
        exit 0
else
        exit 1
fi
