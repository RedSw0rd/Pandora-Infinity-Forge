#!/bin/bash

/usr/sbin/dsniff -h  2>/dev/stdout | grep 'Usage: dsniff' > /dev/null
if [ $? -eq 0 ];
then
        exit 0
else
        exit 1
fi
