#!/bin/bash

/usr/sbin/dsniff -h | grep 'Usage: dsniff' > /dev/null
if [ $? -ne 0 ];
then
        exit 0
else
        exit 1
fi
