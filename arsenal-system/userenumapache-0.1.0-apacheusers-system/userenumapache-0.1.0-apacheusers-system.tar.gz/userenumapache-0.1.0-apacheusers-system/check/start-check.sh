#!/bin/bash

/usr/bin/apache-users | grep 'SSL Support' > /dev/null
if [ $? -eq 0 ];
then
        exit 0
else
        exit 1
fi
