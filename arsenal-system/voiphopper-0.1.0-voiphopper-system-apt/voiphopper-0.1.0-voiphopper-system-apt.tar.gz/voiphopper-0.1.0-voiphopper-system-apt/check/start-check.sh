#!/bin/bash

/usr/bin/voiphopper -h | grep 'VoIP Hopper Extended Usage' > /dev/null
if [ $? -eq 0 ];
then
        exit 0
else
        exit 1
fi
