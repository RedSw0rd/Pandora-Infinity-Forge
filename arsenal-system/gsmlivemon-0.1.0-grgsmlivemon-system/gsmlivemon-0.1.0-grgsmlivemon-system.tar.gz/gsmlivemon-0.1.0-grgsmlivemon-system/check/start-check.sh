#!/bin/bash

/usr/bin/grgsm_livemon --help 2>/dev/null | grep 'Interactive monitor of a single' > /dev/null
if [ $? -eq 0 ];
then
        exit 0
else
        exit 1
fi
