#!/bin/bash

/usr/bin/ping -V | grep 'ping from iputils' > /dev/null
if [ $? -eq 0 ];
then
        exit 0
else
        exit 1
fi
