<?php
/*
|
| On affiche une notification si un mot de passe a ete decouvert.
|
| Si un fichier de session est detecte alors on creer une entree
| dans notre gesionnaire de session.
|
|
*/

// SESSION RECORD
$session_hash_id=md5(file_get_contents("$TMP_DIR_PATH/john.hash"));

if(file_exists("$BRUTE_FORCE_SESSION_DIR_PATH/john/$session_hash_id.pot") && is_file("$BRUTE_FORCE_SESSION_DIR_PATH/john/$session_hash_id.pot"))
{
        $fileContent = file_get_contents("$BRUTE_FORCE_SESSION_DIR_PATH/john/$session_hash_id.pot");
        if (strpos($fileContent, ':') !== false)
        {
                sysnotif("CRACKED", "SUCCESS : Local brute force attack successful! A password/hash has been discovered");
                shell_exec("sudo rm -f $BRUTE_FORCE_SESSION_DIR_PATH/john/$session_hash_id.pot");
        }
}

if(file_exists("$BRUTE_FORCE_SESSION_DIR_PATH/john/$session_hash_id.rec"))
{
        // CHECK IF DB ENTRY EXIST
        $db = new SQLite3("$USER_DB_DIR_PATH/bruteforce.db");
        if($db)
        {
                $smt = $db->prepare("SELECT ID FROM BRUTE_FORCE_SESSION WHERE IP=:session_hash_id AND TYPE = 'JOHN';");
                $smt->bindValue(':session_hash_id', $session_hash_id, SQLITE3_TEXT);
                $r = $smt->execute();
                $row = $r->fetchArray();

                $nid = $row['ID'];
        }

        // CREATE NEW ENTRY IN DB
        if(empty($nid))
        {
                $date = time() ;
                $smt = $db->prepare("INSERT INTO BRUTE_FORCE_SESSION (TYPE, STARTED, IP, PORT, FILEPATH) VALUES ('JOHN', :date, :ip, '-', :path);");
                $smt->bindValue(':date', $date, SQLITE3_TEXT);
                $smt->bindValue(':ip', $session_hash_id, SQLITE3_TEXT);
                $smt->bindValue(':path', "$BRUTE_FORCE_SESSION_DIR_PATH/john/$session_hash_id.rec", SQLITE3_TEXT);
                $smt->execute();
        }
        // UPDATE ENTRY
        else
        {
                $date = time() ;
                $db->querySingle("UPDATE BRUTE_FORCE_SESSION SET PAUSED = '$date' WHERE ID='$nid'");
        }
        $db->close();
}
?>
