#!/bin/bash

/usr/sbin/john --help | grep 'John the Ripper' > /dev/null
if [ $? -eq 0 ];
then
        exit 0
else
        exit 1
fi
