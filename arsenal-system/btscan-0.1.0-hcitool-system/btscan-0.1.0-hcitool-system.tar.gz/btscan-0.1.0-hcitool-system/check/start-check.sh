#!/bin/bash

/usr/bin/hcitool | grep 'HCI Tool ver' > /dev/null
if [ $? -eq 0 ];
then
        exit 0
else
        exit 1
fi
