#!/bin/bash

/usr/bin/dnsrecon -V | grep 'darkoperator' > /dev/null
if [ $? -eq 0 ];
then
        exit 0
else
        exit 1
fi
