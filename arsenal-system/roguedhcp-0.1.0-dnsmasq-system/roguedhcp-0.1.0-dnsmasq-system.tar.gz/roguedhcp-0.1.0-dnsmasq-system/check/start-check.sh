#!/bin/bash

/usr/sbin/dnsmasq --version 2>/dev/stdout | grep 'Simon Kelley' > /dev/null
if [ $? -eq 0 ];
then
        exit 0
else
        exit 1
fi
