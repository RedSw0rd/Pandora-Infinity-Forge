#!/bin/bash

/usr/bin/wpscan -h | grep 'WordPress Security Scanner by the WPScan Team' > /dev/null
if [ $? -eq 0 ];
then
        exit 0
else
        exit 1
fi
