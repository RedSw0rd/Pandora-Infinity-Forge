#!/bin/bash

/usr/bin/nikto -V | grep 'Nikto' > /dev/null
if [ $? -eq 0 ];
then
        exit 0
else
        exit 1
fi
