#!/bin/bash

/usr/sbin/zmap --version | grep zmap > /dev/null
if [ $? -ne 0 ];
then
        exit 0
else
        exit 1
fi
