#!/bin/bash

/usr/bin/tcpdump --version | grep 'tcpdump version' > /dev/null
if [ $? -eq 0 ];
then
        exit 0
else
        exit 1
fi
