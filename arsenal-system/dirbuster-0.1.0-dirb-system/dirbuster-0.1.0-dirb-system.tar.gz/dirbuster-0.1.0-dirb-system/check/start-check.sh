#!/bin/bash

/usr/bin/dirb | grep 'By The Dark Raver' > /dev/null
if [ $? -eq 0 ];
then
        exit 0
else
        exit 1
fi
