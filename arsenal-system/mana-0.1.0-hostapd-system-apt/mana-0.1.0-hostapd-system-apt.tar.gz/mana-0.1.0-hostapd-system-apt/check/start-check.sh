#!/bin/bash

/usr/sbin/hostapd-mana -v  2>/dev/stdout | grep 'User space daemon for IEEE 802.11 AP management' > /dev/null
if [ $? -eq 0 ];
then
        exit 0
else
        exit 1
fi
