#!/bin/bash

/usr/bin/gobuster 2>/dev/stdout | grep 'gobuster [command]' > /dev/null
if [ $? -eq 0 ];
then
        exit 0
else
        exit 1
fi
